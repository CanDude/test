# React Editable Table
This is my first time to use typescript and Vite framework for this test. Hope it will work.

For running command "npm run dev"