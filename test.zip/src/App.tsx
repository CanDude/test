import { EdtiableTable } from "./EditableTable";

function App() {
  return <EdtiableTable />;
}

export default App;
